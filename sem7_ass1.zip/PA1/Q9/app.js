const mongoose = require('mongoose');
const Employee = require('./employee');

// Database connection configuration
const dbConfig = 'mongodb://localhost:27017/company'; // Adjust as necessary

// Function to insert a record into the employee collection
async function insertEmployee(name, position, salary) {
    try {
        const employee = new Employee({ name, position, salary });
        const result = await employee.save();
        console.log(`Inserted employee with ID: ${result._id}`);
    } catch (error) {
        console.error('Error inserting employee:', error.message);
    }
}

// Function to display all records in the employee collection
async function displayEmployees() {
    try {
        const employees = await Employee.find();
        console.log('Employee Records:');
        console.table(employees); // Display records in a table format
    } catch (error) {
        console.error('Error fetching employees:', error.message);
    }
}

// Main function to run the app
(async () => {
    // Connect to the database
    await mongoose.connect(dbConfig, { useNewUrlParser: true, useUnifiedTopology: true });

    // Insert an employee and display all employees
    await insertEmployee('John Doe', 'Software Engineer', 75000);
    await displayEmployees();

    // Close the database connection
    mongoose.connection.close();
})();
