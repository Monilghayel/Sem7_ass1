// employee.js
const mongoose = require('mongoose');

// Define the schema for the employee
const employeeSchema = new mongoose.Schema({
    name: { type: String, required: true },
    position: { type: String, required: true },
    salary: { type: Number, required: true }
});

// Create the model based on the schema
const Employee = mongoose.model('Employee', employeeSchema);

module.exports = Employee;
