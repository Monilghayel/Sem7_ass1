const fs = require('fs');
const path = require('path');
const unzipper = require('unzipper');

/**
 * Extract a ZIP file to a specified directory.
 * @param {string} zipFilePath - The path to the ZIP file.
 * @param {string} outputDir - The directory to extract the contents into.
 */
function extractZip(zipFilePath, outputDir) {
    // Create the output directory if it doesn't exist
    fs.mkdirSync(outputDir, { recursive: true });

    // Create a read stream from the ZIP file
    fs.createReadStream(zipFilePath)
        .pipe(unzipper.Extract({ path: outputDir }))
        .on('close', () => {
            console.log(`Extraction complete! Files extracted to: ${outputDir}`);
        })
        .on('error', (err) => {
            console.error(`Error extracting ZIP file: ${err.message}`);
        });
}

// Usage
const zipFilePath = path.join(__dirname, 'output.zip'); // Change this to your zip file path
const outputDir = path.join(__dirname, 'extracted'); // Change this to your desired output directory

extractZip(zipFilePath, outputDir);

