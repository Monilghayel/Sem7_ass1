const fs = require('fs');
const path = require('path');
const archiver = require('archiver');

/**
 * Create a ZIP file for the specified folder.
 * @param {string} sourceDir - The folder to compress.
 * @param {string} outPath - The output ZIP file path.
 */
function zipFolder(sourceDir, outPath) {
    // Create a file to stream archive data to
    const output = fs.createWriteStream(outPath);
    const archive = archiver('zip', {
        zlib: { level: 9 } // Set the compression level
    });

    output.on('close', () => {
        console.log(`Archive created successfully: ${archive.pointer()} total bytes.`);
    });

    archive.on('error', (err) => {
        throw err;
    });

    // Pipe archive data to the output file
    archive.pipe(output);

    // Append files from the source directory to the archive
    archive.directory(sourceDir, false);

    // Finalize the archive (i.e., finish writing)
    archive.finalize();
}

// Usage
const folderToZip = path.join(__dirname, 'folder-to-zip'); // Change this to your folder
const zipFilePath = path.join(__dirname, 'output.zip'); // Change this to your desired zip file name

zipFolder(folderToZip, zipFilePath);
