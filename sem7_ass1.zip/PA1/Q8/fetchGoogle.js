import fetch from 'node-fetch';

/**
 * Function to fetch data from a URL using async-await.
 * @param {string} url - The URL to fetch data from.
 */
async function fetchData(url) {
    try {
        const response = await fetch(url);

        // Check if the response is OK (status code in the range 200-299)
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        // Get the response text (HTML content)
        const data = await response.text();
        console.log(data); // Print the HTML content
    } catch (error) {
        console.error(`Error fetching data: ${error.message}`);
    }
}

// Usage example
const url = 'https://www.google.com'; // URL to fetch data from
fetchData(url);
