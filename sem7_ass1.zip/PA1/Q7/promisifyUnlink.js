const fs = require('fs');
const util = require('util');

// Promisify the fs.unlink function
const unlinkAsync = util.promisify(fs.unlink);

/**
 * Function to delete a file using the promisified unlink function.
 * @param {string} filePath - The path of the file to delete.
 */
async function deleteFile(filePath) {
    try {
        await unlinkAsync(filePath);
        console.log(`File deleted successfully: ${filePath}`);
    } catch (err) {
        console.error(`Error deleting file: ${err.message}`);
    }
}

// Usage example
const filePath = 'file-to-delete.txt'; // Change this to the file you want to delete

// Create a file for demonstration (you can skip this part if you already have a file)
fs.writeFileSync(filePath, 'This file will be deleted.');

// Call the deleteFile function
deleteFile(filePath);
