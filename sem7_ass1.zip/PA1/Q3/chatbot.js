// chatbot.js

class ChatBot {
  constructor() {
      this.responses = {
          'what is html': 'HTML (HyperText Markup Language) is the standard language for creating web pages.',
          'what is css': 'CSS (Cascading Style Sheets) is used for describing the presentation of a web page.',
          'what is javascript': 'JavaScript is a programming language used to make web pages interactive.',
          'what is react': 'React is a JavaScript library for building user interfaces, maintained by Facebook.',
          'what is nodejs': 'Node.js is a runtime environment that allows you to run JavaScript on the server-side.',
      };
  }

  getResponse(userInput) {
      if (typeof userInput !== 'string') {
          return "I'm sorry, I can only respond to text input.";
      }

      const input = userInput.toLowerCase().trim();
      if (this.responses[input]) {
          return this.responses[input];
      } else {
          return "I'm sorry, I don't understand your question. Please ask something related to web development.";
      }
  }
}

module.exports = ChatBot;
