const express = require('express');
const WebSocket = require('ws');
const path = require('path');
const ChatBot = require('./chatbot');

// Create an Express app
const app = express();
const PORT = process.env.PORT || 3000;

// Serve the static HTML file from the "public" folder
app.use(express.static(path.join(__dirname, 'public')));

// Start the HTTP server
const server = app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

// Initialize WebSocket server
const wss = new WebSocket.Server({ server });

// Create a chatbot instance
const bot = new ChatBot();

// Listen for WebSocket connections
wss.on('connection', (ws) => {
  console.log('New client connected');

  // Listen for messages from the client
  ws.on('message', (message) => {
    console.log(`Received message: ${message}`);

    // Get the response from the chatbot
    const response = bot.getResponse(message);

    // Send the chatbot's response back to the client
    ws.send(response);
  });

  // Log when the client disconnects
  ws.on('close', () => {
    console.log('Client disconnected');
  });
});
