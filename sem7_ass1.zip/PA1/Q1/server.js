// Import express and path modules
const express = require('express');
const path = require('path');

// Create an instance of Express
const app = express();

// Serve static files from a folder (e.g., "public" folder)
app.use(express.static(path.join(__dirname, 'public')));

// Middleware to parse JSON bodies
app.use(express.json());

// Handle GET request
app.get('/api/getData', (req, res) => {
  res.send({ message: 'Hello, this is a GET request!' });
});

// Handle POST request
app.post('/api/postData', (req, res) => {
  const data = req.body;
  res.send({ message: 'POST request received!', data: data });
});

// Start the server on port 3000
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
